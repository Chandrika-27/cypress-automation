import { ISingUp } from "../../test-data-models/test/test.model";

export const tdSignUp: ISingUp = {
    email: 'gajulachandrika.27@gmail.com',
    firstName: 'gajula',
    lastName: 'chandrika'
}