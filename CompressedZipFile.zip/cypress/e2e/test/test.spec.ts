import { TestTask1 } from "./scenarios/test.sc";

describe('Task1 UI verifications', () => {
    const testTask1 = new TestTask1();

    testTask1.task1()
})