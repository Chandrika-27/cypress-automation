export interface ISingUp {
    email: string;
    firstName: string;
    lastName: string;
}
